
from expense_tracker import add_expense, report, summary

expenses = []

while True:
    print("\n1. Add Expense\n2. View All\n3. Filter by Category\n4. Show Total\n5. Exit")
    choice = input("Enter choice: ")

    if choice == '1':
        date = input("Date (YYYY-MM-DD): ")
        cat = input("Category: ")
        amt = float(input("Amount: "))
        desc = input("Description: ")
        add_expense.add_expense(expenses, date, cat, amt, desc)

    elif choice == '2':
        report.show_all(expenses)

    elif choice == '3':
        cat = input("Category: ")
        filtered = report.filter_by_category(expenses, cat)
        report.show_all(filtered)

    elif choice == '4':
        print("Total Spent:", summary.total_expense(expenses))
        print("By Category:", summary.expense_by_category(expenses))

    elif choice == '5':
        break
