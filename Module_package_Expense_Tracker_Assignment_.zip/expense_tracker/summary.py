
def total_expense(expenses):
    return sum(e["amount"] for e in expenses)

def expense_by_category(expenses):
    summary = {}
    for e in expenses:
        summary[e["category"]] = summary.get(e["category"], 0) + e["amount"]
    return summary
