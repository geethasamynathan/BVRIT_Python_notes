
def show_all(expenses):
    for exp in expenses:
        print(exp)

def filter_by_category(expenses, category):
    return [e for e in expenses if e["category"] == category]
