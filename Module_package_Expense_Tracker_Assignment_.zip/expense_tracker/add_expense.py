
def add_expense(expenses, date, category, amount, description):
    expenses.append({
        "date": date,
        "category": category,
        "amount": amount,
        "description": description
    })
