# 📁 Python File and Directory Operations – Tutorial

This tutorial demonstrates how to handle files and directories in Python with real-world use cases.

---

## ✅ 1. List All Files in a Directory

```python
import os

files = os.listdir(".")
print("All files in current directory:", files)
```

---

## ✅ 2. Create a New File

```python
with open("newfile.txt", "w") as file:
    file.write("This is a newly created file.")
print("File created successfully.")
```

---

## ✅ 3. Check if File Exists

```python
import os

if os.path.exists("newfile.txt"):
    print("File exists.")
else:
    print("File does not exist.")
```

---

## ✅ 4. Rename a File

```python
import os

os.rename("newfile.txt", "renamedfile.txt")
print("File renamed.")
```

---

## ✅ 5. Delete a File

```python
import os

if os.path.exists("renamedfile.txt"):
    os.remove("renamedfile.txt")
    print("File deleted.")
else:
    print("File not found.")
```

---

## ✅ 6. Work with Directories

### Create a Directory
```python
import os

os.makedirs("my_data_folder", exist_ok=True)
print("Directory created.")
```

### Change Working Directory
```python
import os

os.chdir("my_data_folder")
print("Changed working directory to:", os.getcwd())
```

---

## ✅ 7. Read from a CSV File

```python
import csv

with open("sample.csv", newline="") as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        print("Row:", row)
```

---

## ✅ 8. Write to a CSV File

```python
import csv

data = [
    ["Name", "Age", "City"],
    ["Alice", 30, "New York"],
    ["Bob", 25, "London"],
    ["Charlie", 35, "Sydney"]
]

with open("output.csv", "w", newline="") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerows(data)
print("Data written to output.csv.")
```

---

## ✅ Real-World Use Case: Data Archiver Script

Imagine you’re building a script that:
- Reads a CSV report.
- Writes filtered rows to a new file.
- Archives old files by renaming.
- Deletes files older than 30 days.
- Organizes output into a subfolder.

All the techniques above would be part of that real-world script.

---
